# Full-Dataset K-Method Benchmark Recommendation

## Decision

- Representation tested: `pretrained_embeddings + pca_then_umap`
- Median prediction-strength K across samples: `12`
- Median gap-statistic K across samples: `50`
- Recommended candidate K for full-data validation: `40`
- Rule: `largest_candidate_with_mean_ari_ge_0.75_and_min_cluster_size_ge_50`

Interpretation: prediction strength estimates the broad stable structure, while gap statistic estimates fine-grained structure. The final candidate K should be the largest tested value that remains stable and avoids tiny clusters.

## Repeated Sample K-Selection

| sample_id | gap_selected_k | prediction_strength_selected_k | support_status | final_stability_ari | final_silhouette | final_davies_bouldin |
| --- | --- | --- | --- | --- | --- | --- |
| sample_10k_seed101 | 50 | 14 | gap_and_prediction_strength_disagree | 0.7464 | 0.3216 | 1.0421 |
| sample_10k_seed202 | 40 | 9 | gap_and_prediction_strength_disagree | 0.7533 | 0.3462 | 1.0150 |
| sample_10k_seed303 | 44 | 12 | gap_and_prediction_strength_disagree | 0.7700 | 0.3180 | 1.0516 |
| sample_10k_seed404 | 63 | 18 | gap_and_prediction_strength_disagree | 0.7287 | 0.3100 | 1.0310 |
| sample_10k_seed505 | 65 | 10 | gap_and_prediction_strength_disagree | 0.7167 | 0.3065 | 1.0895 |

## Candidate K Validation Summary

| candidate_k | sample_count | stability_mean_ari_mean | stability_mean_ari_std | silhouette_score_mean | davies_bouldin_score_mean | min_cluster_size_min | p10_cluster_size_mean | clusters_under_50_mean |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 5.0000 | 5.0000 | 0.9947 | 0.0023 | 0.4725 | 0.7332 | 936.0000 | 1091.2000 | 0.0000 |
| 8.0000 | 5.0000 | 0.9660 | 0.0421 | 0.4233 | 0.8613 | 463.0000 | 734.4000 | 0.0000 |
| 10.0000 | 5.0000 | 0.9479 | 0.0646 | 0.4158 | 0.8958 | 332.0000 | 643.4000 | 0.0000 |
| 12.0000 | 5.0000 | 0.8927 | 0.0575 | 0.4146 | 0.8990 | 340.0000 | 461.0000 | 0.0000 |
| 15.0000 | 5.0000 | 0.8751 | 0.0613 | 0.4039 | 0.8966 | 135.0000 | 399.0000 | 0.0000 |
| 20.0000 | 5.0000 | 0.8948 | 0.0782 | 0.4025 | 0.8623 | 98.0000 | 265.4000 | 0.0000 |
| 30.0000 | 5.0000 | 0.8221 | 0.0244 | 0.3769 | 0.9322 | 75.0000 | 183.2000 | 0.0000 |
| 40.0000 | 5.0000 | 0.7678 | 0.0192 | 0.3444 | 1.0031 | 75.0000 | 141.4000 | 0.0000 |
| 50.0000 | 5.0000 | 0.7360 | 0.0191 | 0.3318 | 1.0386 | 59.0000 | 111.0000 | 0.0000 |
| 60.0000 | 5.0000 | 0.7383 | 0.0277 | 0.3249 | 1.0422 | 41.0000 | 88.0000 | 0.4000 |
| 80.0000 | 5.0000 | 0.7083 | 0.0286 | 0.3137 | 1.0558 | 23.0000 | 62.0000 | 3.4000 |
| 100.0000 | 5.0000 | 0.7012 | 0.0140 | 0.3072 | 1.0596 | 19.0000 | 46.6000 | 11.8000 |
