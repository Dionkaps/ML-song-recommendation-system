# KMeans K-Selection Report

Selected K: 50
Primary rule: gap_statistic_one_standard_error
Support status: gap_and_prediction_strength_disagree
Prediction-strength selected K: 14
Bootstrap stability ARI: 0.7464486852690473

## Selected Row

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 50.00000 | 3.43455 | 0.00302 | 0.31063 | 0.33398 | 9829.12844 | 1.02735 |

## Highest Gap / Stability Candidates

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 100.00000 | 3.81635 | 0.00282 | 0.19200 | 0.30140 | 8013.51100 | 1.05259 |
| 99.00000 | 3.81445 | 0.00343 | 0.16858 | 0.29312 | 8066.96572 | 1.04883 |
| 98.00000 | 3.81047 | 0.00268 | 0.21440 | 0.29934 | 8100.33777 | 1.06220 |
| 97.00000 | 3.80494 | 0.00273 | 0.19615 | 0.29806 | 8111.88188 | 1.04446 |
| 96.00000 | 3.80294 | 0.00281 | 0.17710 | 0.29784 | 8171.21158 | 1.08045 |
| 94.00000 | 3.78865 | 0.00168 | 0.18050 | 0.30076 | 8203.83970 | 1.06072 |
| 95.00000 | 3.78682 | 0.00350 | 0.22735 | 0.28943 | 8115.71422 | 1.06278 |
| 93.00000 | 3.77981 | 0.00282 | 0.19610 | 0.30294 | 8205.11723 | 1.05828 |
| 92.00000 | 3.77455 | 0.00268 | 0.22875 | 0.30462 | 8233.39603 | 1.06052 |
| 91.00000 | 3.76404 | 0.00252 | 0.15495 | 0.31764 | 8232.52296 | 1.05268 |
| 90.00000 | 3.76189 | 0.00266 | 0.21024 | 0.30737 | 8285.81200 | 1.07389 |
| 89.00000 | 3.75707 | 0.00245 | 0.20003 | 0.30639 | 8322.88124 | 1.06806 |

## Decision Notes

The selected K is the smallest candidate satisfying the gap statistic one-standard-error rule. Prediction strength and bootstrap ARI are reproducibility checks; silhouette, Calinski-Harabasz, and Davies-Bouldin are supporting internal validity evidence.
