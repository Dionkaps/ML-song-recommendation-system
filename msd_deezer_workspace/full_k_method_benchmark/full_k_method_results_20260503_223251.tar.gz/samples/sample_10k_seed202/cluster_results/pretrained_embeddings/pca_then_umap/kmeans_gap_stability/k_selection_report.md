# KMeans K-Selection Report

Selected K: 40
Primary rule: gap_statistic_one_standard_error
Support status: gap_and_prediction_strength_disagree
Prediction-strength selected K: 9
Bootstrap stability ARI: 0.7532930370503449

## Selected Row

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 40.00000 | 3.09760 | 0.00201 | 0.35069 | 0.35517 | 10972.32819 | 0.98737 |

## Highest Gap / Stability Candidates

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 100.00000 | 3.57068 | 0.00248 | 0.19905 | 0.29464 | 8330.67888 | 1.08786 |
| 99.00000 | 3.56592 | 0.00306 | 0.16326 | 0.29235 | 8373.79959 | 1.07244 |
| 98.00000 | 3.56445 | 0.00260 | 0.20781 | 0.29822 | 8423.91271 | 1.07498 |
| 97.00000 | 3.55313 | 0.00333 | 0.17324 | 0.30477 | 8393.14221 | 1.09200 |
| 95.00000 | 3.55226 | 0.00322 | 0.18029 | 0.29687 | 8529.79305 | 1.07870 |
| 96.00000 | 3.55210 | 0.00145 | 0.16289 | 0.30113 | 8450.53226 | 1.07690 |
| 94.00000 | 3.53940 | 0.00262 | 0.22349 | 0.29542 | 8502.49358 | 1.07039 |
| 93.00000 | 3.53064 | 0.00148 | 0.20896 | 0.30495 | 8500.18000 | 1.07524 |
| 91.00000 | 3.52873 | 0.00185 | 0.22787 | 0.30339 | 8635.14337 | 1.07377 |
| 92.00000 | 3.52823 | 0.00221 | 0.18445 | 0.30263 | 8554.43188 | 1.07394 |
| 90.00000 | 3.52705 | 0.00330 | 0.18151 | 0.30385 | 8685.84477 | 1.04941 |
| 89.00000 | 3.52002 | 0.00230 | 0.21994 | 0.29042 | 8722.36874 | 1.06324 |

## Decision Notes

The selected K is the smallest candidate satisfying the gap statistic one-standard-error rule. Prediction strength and bootstrap ARI are reproducibility checks; silhouette, Calinski-Harabasz, and Davies-Bouldin are supporting internal validity evidence.
