# KMeans K-Selection Report

Selected K: 63
Primary rule: gap_statistic_one_standard_error
Support status: gap_and_prediction_strength_disagree
Prediction-strength selected K: 18
Bootstrap stability ARI: 0.7286868264690792

## Selected Row

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 63.00000 | 3.37370 | 0.00277 | 0.28420 | 0.32143 | 9145.98355 | 0.99896 |

## Highest Gap / Stability Candidates

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 100.00000 | 3.61888 | 0.00316 | 0.22612 | 0.31100 | 8043.75939 | 1.04545 |
| 99.00000 | 3.61430 | 0.00295 | 0.17931 | 0.31039 | 8086.05359 | 1.02937 |
| 96.00000 | 3.60765 | 0.00153 | 0.20920 | 0.32082 | 8224.77344 | 1.02226 |
| 97.00000 | 3.60666 | 0.00226 | 0.22177 | 0.30602 | 8140.13887 | 1.03728 |
| 98.00000 | 3.60610 | 0.00263 | 0.22132 | 0.30429 | 8084.96998 | 1.03748 |
| 95.00000 | 3.58882 | 0.00331 | 0.22914 | 0.30572 | 8136.81961 | 1.03511 |
| 94.00000 | 3.58602 | 0.00176 | 0.21009 | 0.31537 | 8186.64196 | 1.02288 |
| 93.00000 | 3.57965 | 0.00312 | 0.21472 | 0.31234 | 8209.57285 | 1.04411 |
| 92.00000 | 3.57227 | 0.00269 | 0.22967 | 0.31448 | 8209.72206 | 1.04024 |
| 91.00000 | 3.56980 | 0.00154 | 0.25792 | 0.32025 | 8272.52859 | 1.03526 |
| 90.00000 | 3.56437 | 0.00365 | 0.24178 | 0.31384 | 8288.62327 | 1.04194 |
| 89.00000 | 3.55499 | 0.00301 | 0.22830 | 0.32115 | 8293.51444 | 1.04671 |

## Decision Notes

The selected K is the smallest candidate satisfying the gap statistic one-standard-error rule. Prediction strength and bootstrap ARI are reproducibility checks; silhouette, Calinski-Harabasz, and Davies-Bouldin are supporting internal validity evidence.
