# KMeans K-Selection Report

Selected K: 44
Primary rule: gap_statistic_one_standard_error
Support status: gap_and_prediction_strength_disagree
Prediction-strength selected K: 12
Bootstrap stability ARI: 0.7699661097020141

## Selected Row

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 44.00000 | 3.14943 | 0.00101 | 0.27216 | 0.32860 | 10587.83649 | 1.05522 |

## Highest Gap / Stability Candidates

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 100.00000 | 3.56446 | 0.00322 | 0.14619 | 0.29373 | 8306.40355 | 1.06295 |
| 99.00000 | 3.56268 | 0.00386 | 0.20086 | 0.29126 | 8365.70695 | 1.06104 |
| 98.00000 | 3.55551 | 0.00293 | 0.20508 | 0.30565 | 8370.48935 | 1.06744 |
| 97.00000 | 3.55068 | 0.00232 | 0.17524 | 0.29807 | 8390.30962 | 1.07907 |
| 96.00000 | 3.54459 | 0.00116 | 0.20390 | 0.29700 | 8411.53561 | 1.06900 |
| 95.00000 | 3.54144 | 0.00368 | 0.20109 | 0.30071 | 8460.22787 | 1.07376 |
| 94.00000 | 3.53165 | 0.00223 | 0.20441 | 0.29520 | 8453.81726 | 1.07698 |
| 93.00000 | 3.52493 | 0.00244 | 0.21917 | 0.31208 | 8474.74842 | 1.06569 |
| 92.00000 | 3.52435 | 0.00254 | 0.20322 | 0.30800 | 8533.27558 | 1.07000 |
| 91.00000 | 3.51574 | 0.00311 | 0.18783 | 0.30053 | 8539.75121 | 1.09266 |
| 90.00000 | 3.51305 | 0.00262 | 0.21391 | 0.29724 | 8577.39127 | 1.07565 |
| 89.00000 | 3.50353 | 0.00196 | 0.19147 | 0.30321 | 8584.39565 | 1.08796 |

## Decision Notes

The selected K is the smallest candidate satisfying the gap statistic one-standard-error rule. Prediction strength and bootstrap ARI are reproducibility checks; silhouette, Calinski-Harabasz, and Davies-Bouldin are supporting internal validity evidence.
