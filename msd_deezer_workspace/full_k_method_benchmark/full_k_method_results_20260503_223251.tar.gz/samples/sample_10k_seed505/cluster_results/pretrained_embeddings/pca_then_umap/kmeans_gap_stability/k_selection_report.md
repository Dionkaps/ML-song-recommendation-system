# KMeans K-Selection Report

Selected K: 65
Primary rule: gap_statistic_one_standard_error
Support status: gap_and_prediction_strength_disagree
Prediction-strength selected K: 10
Bootstrap stability ARI: 0.7167473288555395

## Selected Row

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 65.00000 | 3.30132 | 0.00322 | 0.24842 | 0.32380 | 9112.69716 | 1.04848 |

## Highest Gap / Stability Candidates

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 100.00000 | 3.52997 | 0.00265 | 0.22301 | 0.30298 | 8028.98024 | 1.04914 |
| 99.00000 | 3.52054 | 0.00286 | 0.20107 | 0.30667 | 8042.75555 | 1.07896 |
| 98.00000 | 3.51490 | 0.00258 | 0.20548 | 0.31113 | 8055.63024 | 1.05009 |
| 97.00000 | 3.51469 | 0.00392 | 0.21381 | 0.30688 | 8111.69173 | 1.05973 |
| 96.00000 | 3.50600 | 0.00186 | 0.20366 | 0.31050 | 8108.39605 | 1.05087 |
| 95.00000 | 3.50468 | 0.00302 | 0.21427 | 0.31148 | 8178.64573 | 1.03545 |
| 94.00000 | 3.49343 | 0.00186 | 0.23501 | 0.31309 | 8153.58829 | 1.07374 |
| 93.00000 | 3.48652 | 0.00234 | 0.21163 | 0.30545 | 8169.89084 | 1.04332 |
| 92.00000 | 3.48476 | 0.00199 | 0.20917 | 0.29982 | 8225.04731 | 1.05510 |
| 91.00000 | 3.48221 | 0.00216 | 0.16354 | 0.30858 | 8289.64167 | 1.05613 |
| 90.00000 | 3.47070 | 0.00183 | 0.17691 | 0.29625 | 8252.72831 | 1.05502 |
| 89.00000 | 3.46075 | 0.00205 | 0.20483 | 0.31172 | 8256.68294 | 1.06628 |

## Decision Notes

The selected K is the smallest candidate satisfying the gap statistic one-standard-error rule. Prediction strength and bootstrap ARI are reproducibility checks; silhouette, Calinski-Harabasz, and Davies-Bouldin are supporting internal validity evidence.
