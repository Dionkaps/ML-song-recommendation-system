# KMeans K-Selection Benchmark Summary

Each row is one feature source and dimensionality-reduction recipe. The selected K comes from the gap statistic one-standard-error rule; prediction strength and bootstrap ARI report stability support.

## Runs Needing Interpretation Review

| feature_source | reduction | selected_k | prediction_strength_selected_k | support_status | prediction_strength | stability_ari |
| --- | --- | --- | --- | --- | --- | --- |
| pretrained_embeddings | pca_then_umap | 41 | 10 | gap_and_prediction_strength_disagree | 0.3754 | 0.8219 |
| pretrained_embeddings | umap_only | 55 | 8 | gap_and_prediction_strength_disagree | 0.3000 | 0.7490 |
| pretrained_embeddings | pca_only | 19 | 7 | gap_and_prediction_strength_disagree | 0.3106 | 0.6992 |
| features | pca_then_umap | 56 | 5 | gap_and_prediction_strength_disagree | 0.2315 | 0.6129 |
| features | umap_only | 60 | 5 | gap_and_prediction_strength_disagree | 0.2236 | 0.5800 |
| features | pca_only | 14 | 5 | gap_and_prediction_strength_disagree | 0.2896 | 0.5892 |

## Full Results

| feature_source | reduction | selected_k | prediction_strength_selected_k | support_status | gap | prediction_strength | silhouette | calinski_harabasz | davies_bouldin | dunn | trustworthiness | stability_ari |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| features | pca_only | 14 | 5 | gap_and_prediction_strength_disagree | 1.7417 | 0.2896 | 0.0273 | 379.2080 | 3.6098 | 0.2226 | 0.9999 | 0.5892 |
| features | pca_then_umap | 56 | 5 | gap_and_prediction_strength_disagree | 2.7666 | 0.2315 | 0.2540 | 6073.9057 | 1.1130 | 0.0268 | 0.9049 | 0.6129 |
| features | umap_only | 60 | 5 | gap_and_prediction_strength_disagree | 2.7464 | 0.2236 | 0.2451 | 5803.9929 | 1.1341 | 0.0200 | 0.9040 | 0.5800 |
| pretrained_embeddings | pca_only | 19 | 7 | gap_and_prediction_strength_disagree | 1.6083 | 0.3106 | 0.0582 | 293.8604 | 3.1045 | 0.2323 | 0.9998 | 0.6992 |
| pretrained_embeddings | pca_then_umap | 41 | 10 | gap_and_prediction_strength_disagree | 3.1402 | 0.3754 | 0.3487 | 10992.6370 | 0.9594 | 0.0167 | 0.9506 | 0.8219 |
| pretrained_embeddings | umap_only | 55 | 8 | gap_and_prediction_strength_disagree | 3.2600 | 0.3000 | 0.3132 | 10145.3763 | 1.0755 | 0.0052 | 0.9481 | 0.7490 |
