# KMeans K-Selection Report

Selected K: 14
Primary rule: gap_statistic_one_standard_error
Support status: gap_and_prediction_strength_disagree
Prediction-strength selected K: 5
Bootstrap stability ARI: 0.589218543519016

## Selected Row

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 14.00000 | 1.74171 | 0.00127 | 0.28961 | 0.02280 | 364.82094 | 3.62136 |

## Highest Gap / Stability Candidates

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 59.00000 | 1.76966 | 0.00115 | 0.06438 | -0.00787 | 103.97128 | 3.97378 |
| 60.00000 | 1.76964 | 0.00103 | 0.07452 | -0.00617 | 102.50726 | 4.02316 |
| 58.00000 | 1.76883 | 0.00160 | 0.06901 | -0.00786 | 105.52911 | 3.97399 |
| 54.00000 | 1.76881 | 0.00107 | 0.06740 | -0.00373 | 112.44372 | 4.00553 |
| 57.00000 | 1.76844 | 0.00071 | 0.06572 | -0.00722 | 107.11689 | 4.02140 |
| 56.00000 | 1.76802 | 0.00119 | 0.06695 | -0.00923 | 108.84088 | 3.98061 |
| 55.00000 | 1.76774 | 0.00092 | 0.07577 | -0.00912 | 110.43407 | 4.00044 |
| 53.00000 | 1.76774 | 0.00066 | 0.07286 | -0.00583 | 114.11489 | 3.98578 |
| 52.00000 | 1.76769 | 0.00049 | 0.07733 | -0.00412 | 116.23483 | 3.98979 |
| 51.00000 | 1.76757 | 0.00079 | 0.06979 | -0.00453 | 118.09589 | 3.99984 |
| 48.00000 | 1.76666 | 0.00131 | 0.07532 | -0.00628 | 124.48801 | 4.01832 |
| 50.00000 | 1.76592 | 0.00087 | 0.08269 | -0.00566 | 120.09614 | 4.03191 |

## Decision Notes

The selected K is the smallest candidate satisfying the gap statistic one-standard-error rule. Prediction strength and bootstrap ARI are reproducibility checks; silhouette, Calinski-Harabasz, and Davies-Bouldin are supporting internal validity evidence.
