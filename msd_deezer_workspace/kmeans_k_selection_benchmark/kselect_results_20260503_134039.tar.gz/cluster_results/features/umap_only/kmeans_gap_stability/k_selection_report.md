# KMeans K-Selection Report

Selected K: 60
Primary rule: gap_statistic_one_standard_error
Support status: gap_and_prediction_strength_disagree
Prediction-strength selected K: 5
Bootstrap stability ARI: 0.5799699733971106

## Selected Row

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 60.00000 | 2.74635 | 0.00142 | 0.22361 | 0.25042 | 5647.73168 | 1.12399 |

## Highest Gap / Stability Candidates

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 60.00000 | 2.74635 | 0.00142 | 0.22361 | 0.25042 | 5647.73168 | 1.12399 |
| 59.00000 | 2.74101 | 0.00348 | 0.24316 | 0.24726 | 5689.98020 | 1.12310 |
| 58.00000 | 2.73478 | 0.00258 | 0.23372 | 0.25131 | 5739.36600 | 1.10976 |
| 57.00000 | 2.72628 | 0.00333 | 0.22658 | 0.24853 | 5763.63097 | 1.10221 |
| 56.00000 | 2.71583 | 0.00186 | 0.20505 | 0.24262 | 5791.52949 | 1.11434 |
| 55.00000 | 2.70739 | 0.00239 | 0.21958 | 0.25403 | 5823.46173 | 1.12655 |
| 54.00000 | 2.69861 | 0.00283 | 0.25334 | 0.25508 | 5874.50420 | 1.10239 |
| 53.00000 | 2.69131 | 0.00336 | 0.20735 | 0.26384 | 5907.71326 | 1.09774 |
| 52.00000 | 2.68169 | 0.00356 | 0.22431 | 0.24764 | 5952.86895 | 1.10851 |
| 51.00000 | 2.67493 | 0.00231 | 0.24253 | 0.26205 | 6006.23444 | 1.07804 |
| 50.00000 | 2.67010 | 0.00153 | 0.23613 | 0.25073 | 6073.98925 | 1.08941 |
| 49.00000 | 2.65752 | 0.00244 | 0.24153 | 0.25089 | 6098.99207 | 1.08728 |

## Decision Notes

The selected K is the smallest candidate satisfying the gap statistic one-standard-error rule. Prediction strength and bootstrap ARI are reproducibility checks; silhouette, Calinski-Harabasz, and Davies-Bouldin are supporting internal validity evidence.
