# KMeans K-Selection Report

Selected K: 56
Primary rule: gap_statistic_one_standard_error
Support status: gap_and_prediction_strength_disagree
Prediction-strength selected K: 5
Bootstrap stability ARI: 0.612918447039031

## Selected Row

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 56.00000 | 2.76657 | 0.00165 | 0.23150 | 0.25407 | 5977.97407 | 1.08034 |

## Highest Gap / Stability Candidates

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 60.00000 | 2.79880 | 0.00256 | 0.24785 | 0.24898 | 5833.09045 | 1.08461 |
| 59.00000 | 2.78848 | 0.00411 | 0.21993 | 0.24753 | 5848.26560 | 1.10620 |
| 58.00000 | 2.77932 | 0.00221 | 0.21773 | 0.25573 | 5881.25947 | 1.09736 |
| 57.00000 | 2.76938 | 0.00336 | 0.23491 | 0.25115 | 5899.10548 | 1.09533 |
| 56.00000 | 2.76657 | 0.00165 | 0.23150 | 0.25407 | 5977.97407 | 1.08034 |
| 55.00000 | 2.75998 | 0.00190 | 0.22521 | 0.25239 | 6012.19496 | 1.08365 |
| 54.00000 | 2.74430 | 0.00230 | 0.22932 | 0.24973 | 6023.10574 | 1.10241 |
| 53.00000 | 2.73872 | 0.00378 | 0.23109 | 0.25110 | 6069.84686 | 1.10487 |
| 52.00000 | 2.73013 | 0.00367 | 0.24587 | 0.25772 | 6116.89852 | 1.08029 |
| 51.00000 | 2.72008 | 0.00204 | 0.22472 | 0.25346 | 6148.43611 | 1.09404 |
| 50.00000 | 2.70844 | 0.00255 | 0.25817 | 0.24946 | 6186.11597 | 1.09037 |
| 49.00000 | 2.70286 | 0.00297 | 0.25715 | 0.26025 | 6236.45579 | 1.10634 |

## Decision Notes

The selected K is the smallest candidate satisfying the gap statistic one-standard-error rule. Prediction strength and bootstrap ARI are reproducibility checks; silhouette, Calinski-Harabasz, and Davies-Bouldin are supporting internal validity evidence.
