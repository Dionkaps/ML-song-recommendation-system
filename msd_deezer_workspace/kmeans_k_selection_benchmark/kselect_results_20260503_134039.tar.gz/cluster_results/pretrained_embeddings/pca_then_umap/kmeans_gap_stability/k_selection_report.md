# KMeans K-Selection Report

Selected K: 41
Primary rule: gap_statistic_one_standard_error
Support status: gap_and_prediction_strength_disagree
Prediction-strength selected K: 10
Bootstrap stability ARI: 0.821902375735454

## Selected Row

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 41.00000 | 3.14017 | 0.00317 | 0.37536 | 0.35879 | 11055.05732 | 0.93546 |

## Highest Gap / Stability Candidates

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 60.00000 | 3.32366 | 0.00307 | 0.31741 | 0.31526 | 9862.28617 | 1.02122 |
| 59.00000 | 3.31412 | 0.00299 | 0.26308 | 0.31621 | 9886.03613 | 1.02059 |
| 58.00000 | 3.29914 | 0.00395 | 0.27220 | 0.33053 | 9877.01921 | 1.02370 |
| 57.00000 | 3.29799 | 0.00304 | 0.30215 | 0.32105 | 10001.57152 | 1.00603 |
| 56.00000 | 3.28585 | 0.00184 | 0.32311 | 0.31952 | 10025.65034 | 1.00737 |
| 55.00000 | 3.28228 | 0.00210 | 0.30540 | 0.31552 | 10111.20688 | 1.02522 |
| 54.00000 | 3.26859 | 0.00204 | 0.30029 | 0.32397 | 10134.10505 | 1.01202 |
| 53.00000 | 3.26113 | 0.00298 | 0.31096 | 0.32701 | 10194.98986 | 1.00186 |
| 52.00000 | 3.25247 | 0.00334 | 0.32491 | 0.32827 | 10272.36494 | 1.04316 |
| 51.00000 | 3.24801 | 0.00359 | 0.34038 | 0.33509 | 10378.91516 | 0.98955 |
| 50.00000 | 3.23065 | 0.00205 | 0.39056 | 0.33128 | 10364.44500 | 1.01876 |
| 49.00000 | 3.22473 | 0.00212 | 0.31571 | 0.34069 | 10455.30788 | 0.99570 |

## Decision Notes

The selected K is the smallest candidate satisfying the gap statistic one-standard-error rule. Prediction strength and bootstrap ARI are reproducibility checks; silhouette, Calinski-Harabasz, and Davies-Bouldin are supporting internal validity evidence.
