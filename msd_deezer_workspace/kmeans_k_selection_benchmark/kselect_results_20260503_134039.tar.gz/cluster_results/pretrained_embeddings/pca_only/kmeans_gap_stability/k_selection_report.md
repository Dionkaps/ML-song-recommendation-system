# KMeans K-Selection Report

Selected K: 19
Primary rule: gap_statistic_one_standard_error
Support status: gap_and_prediction_strength_disagree
Prediction-strength selected K: 7
Bootstrap stability ARI: 0.6991781524945089

## Selected Row

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 19.00000 | 1.60832 | 0.00138 | 0.31057 | 0.06416 | 290.27850 | 3.04984 |

## Highest Gap / Stability Candidates

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 59.00000 | 1.66468 | 0.00123 | 0.11271 | 0.03613 | 121.47615 | 3.16498 |
| 60.00000 | 1.66467 | 0.00130 | 0.09905 | 0.03535 | 119.71683 | 3.20935 |
| 57.00000 | 1.66266 | 0.00109 | 0.10388 | 0.03531 | 124.77109 | 3.18473 |
| 58.00000 | 1.66258 | 0.00173 | 0.10013 | 0.03497 | 122.90260 | 3.19657 |
| 54.00000 | 1.66145 | 0.00121 | 0.09636 | 0.03733 | 130.40040 | 3.13264 |
| 56.00000 | 1.66123 | 0.00101 | 0.10905 | 0.03453 | 126.52964 | 3.17792 |
| 55.00000 | 1.66096 | 0.00094 | 0.10845 | 0.03726 | 128.34254 | 3.17799 |
| 53.00000 | 1.66005 | 0.00076 | 0.12089 | 0.03790 | 132.27397 | 3.11789 |
| 52.00000 | 1.65939 | 0.00061 | 0.12817 | 0.03406 | 134.45347 | 3.14784 |
| 51.00000 | 1.65748 | 0.00113 | 0.10702 | 0.03370 | 136.01465 | 3.22824 |
| 50.00000 | 1.65735 | 0.00095 | 0.12966 | 0.04002 | 138.64190 | 3.19176 |
| 49.00000 | 1.65646 | 0.00161 | 0.11053 | 0.03582 | 140.70672 | 3.11970 |

## Decision Notes

The selected K is the smallest candidate satisfying the gap statistic one-standard-error rule. Prediction strength and bootstrap ARI are reproducibility checks; silhouette, Calinski-Harabasz, and Davies-Bouldin are supporting internal validity evidence.
