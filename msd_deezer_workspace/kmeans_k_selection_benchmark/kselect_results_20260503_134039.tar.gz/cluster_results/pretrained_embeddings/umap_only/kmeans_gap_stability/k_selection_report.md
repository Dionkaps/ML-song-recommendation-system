# KMeans K-Selection Report

Selected K: 55
Primary rule: gap_statistic_one_standard_error
Support status: gap_and_prediction_strength_disagree
Prediction-strength selected K: 8
Bootstrap stability ARI: 0.7489975679420415

## Selected Row

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 55.00000 | 3.26003 | 0.00332 | 0.29996 | 0.31021 | 10175.20968 | 1.04590 |

## Highest Gap / Stability Candidates

| cluster_count | gap | gap_sk | prediction_strength_mean | silhouette_score | calinski_harabasz_score | davies_bouldin_score |
| --- | --- | --- | --- | --- | --- | --- |
| 60.00000 | 3.29846 | 0.00261 | 0.26546 | 0.31047 | 9880.51473 | 1.07230 |
| 59.00000 | 3.29507 | 0.00285 | 0.23993 | 0.32479 | 9959.14085 | 1.07897 |
| 58.00000 | 3.27996 | 0.00251 | 0.24975 | 0.31282 | 9962.56412 | 1.05957 |
| 57.00000 | 3.27567 | 0.00266 | 0.29973 | 0.32200 | 10050.45081 | 1.06963 |
| 55.00000 | 3.26003 | 0.00332 | 0.29996 | 0.31021 | 10175.20968 | 1.04590 |
| 56.00000 | 3.25895 | 0.00287 | 0.29186 | 0.31328 | 10048.20284 | 1.05290 |
| 54.00000 | 3.25059 | 0.00300 | 0.31082 | 0.32679 | 10240.33015 | 1.04904 |
| 53.00000 | 3.24437 | 0.00326 | 0.28442 | 0.31883 | 10321.98521 | 1.04955 |
| 52.00000 | 3.23046 | 0.00358 | 0.27837 | 0.32944 | 10348.15737 | 1.04193 |
| 51.00000 | 3.22621 | 0.00232 | 0.31581 | 0.32300 | 10462.94844 | 1.03011 |
| 50.00000 | 3.21715 | 0.00271 | 0.28842 | 0.32177 | 10529.60844 | 1.03510 |
| 49.00000 | 3.19903 | 0.00288 | 0.36389 | 0.32112 | 10506.57761 | 1.04142 |

## Decision Notes

The selected K is the smallest candidate satisfying the gap statistic one-standard-error rule. Prediction strength and bootstrap ARI are reproducibility checks; silhouette, Calinski-Harabasz, and Davies-Bouldin are supporting internal validity evidence.
